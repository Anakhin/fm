Plug-in "Torrent Info" for Far Manager 3.0
*******************************************

Plug-in that allows you to view the content of torrent files (*.torrent).

Install:
  Unpack the archive to the Far plugins directory (...Far\Plugins).

Warning:
  This plugin is provided "as is". The author is not responsible for the
  consequences of use of this software.

Artem Senichev (artemsen@gmail.com)
               http://code.google.com/p/farplugs
