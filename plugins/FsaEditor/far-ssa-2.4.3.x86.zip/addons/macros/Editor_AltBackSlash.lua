Macro {
area="Editor"; key="AltBackSlash"; flags="DisableOutput"; description="SSA Set end and start of next"; action=function()
Keys("F11 s t e Down F11 s t s")
end;
}
