Macro {
area="Editor"; key="CtrlAltDown"; flags="DisableOutput"; description="SSA Move phrase down"; action=function()
Keys("F11 s h d")
end;
}
