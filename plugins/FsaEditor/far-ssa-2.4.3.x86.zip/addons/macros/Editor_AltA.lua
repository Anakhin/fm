Macro {
area="Editor"; key="AltA"; flags="DisableOutput"; description="SSA Style 4"; action=function()
Keys("F11 s y 4")
end;
}
