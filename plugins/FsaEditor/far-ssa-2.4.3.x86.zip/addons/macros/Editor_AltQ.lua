Macro {
area="Editor"; key="AltQ"; flags="DisableOutput"; description="SSA Style 7"; action=function()
Keys("F11 s y 7")
end;
}
