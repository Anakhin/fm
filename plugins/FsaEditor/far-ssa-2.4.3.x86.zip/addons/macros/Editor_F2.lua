Macro {
area="Editor"; key="F2"; flags="DisableOutput"; description="SSA Save and Reload"; action=function()
Keys("F2 F11 s r")
end;
}
