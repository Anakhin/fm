Macro {
area="Editor"; key="AltD"; flags="DisableOutput"; description="SSA Style 6"; action=function()
Keys("F11 s y 6")
end;
}
