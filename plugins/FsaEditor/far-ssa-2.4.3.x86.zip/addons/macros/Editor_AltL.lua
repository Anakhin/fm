Macro {
area="Editor"; key="AltL"; flags="DisableOutput"; description="SSA Shift Remainder +0.1s"; action=function()
Keys("F11 s t h r Space 0 0 0 0 0 1 0 Enter")
end;
}
