Macro {
area="Editor"; key="Alt-"; flags="DisableOutput"; description="SSA Set start of phrase"; action=function()
Keys("F11 s t s")
end;
}
