Macro {
area="Editor"; key="AltF"; flags="DisableOutput"; description="SSA Fix overlay"; action=function()
Keys("F11 s h o")
end;
}
