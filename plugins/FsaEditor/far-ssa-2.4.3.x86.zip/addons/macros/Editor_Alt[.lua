Macro {
area="Editor"; key="Alt["; flags="DisableOutput"; description="SSA Seek Start of phrase"; action=function()
Keys("F11 s s s")
end;
}
