Macro {
area="Editor"; key="AltC"; flags="DisableOutput"; description="SSA Style 3"; action=function()
Keys("F11 s y 3")
end;
}
