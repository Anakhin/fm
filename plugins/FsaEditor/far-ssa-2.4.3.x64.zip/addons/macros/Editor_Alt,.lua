Macro {
area="Editor"; key="Alt,"; flags="DisableOutput"; description="SSA Shift Phrase -0.1s"; action=function()
Keys("F11 s t h p - 0 0 0 0 0 1 0 Enter")
end;
}
