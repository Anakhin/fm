Macro {
area="Editor"; key="AltX"; flags="DisableOutput"; description="SSA Style 2"; action=function()
Keys("F11 s y 2")
end;
}
