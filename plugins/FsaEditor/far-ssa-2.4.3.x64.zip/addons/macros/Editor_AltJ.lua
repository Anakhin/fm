Macro {
area="Editor"; key="AltJ"; flags="DisableOutput"; description="SSA Splice phrases"; action=function()
Keys("F11 s h p")
end;
}
