Macro {
area="Editor"; key="Alt'"; flags="DisableOutput"; description="SSA Shift Remainder +0.1s"; action=function()
Keys("CtrlShift0 F11 s t d Space 0 0 0 0 0 1 0 Enter Down F11 s t h r Space 0 0 0 0 0 1 0 Enter Ctrl0")
end;
}