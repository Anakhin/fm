Macro {
area="Editor"; key="AltZ"; flags="DisableOutput"; description="SSA Style 1"; action=function()
Keys("F11 s y 1")
end;
}
