Macro {
area="Editor"; key="Alt`"; flags="DisableOutput"; description="SSA Pause"; action=function()
Keys("F11 s p")
end;
}
