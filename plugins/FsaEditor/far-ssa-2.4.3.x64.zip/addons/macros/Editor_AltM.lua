Macro {
area="Editor"; key="AltM"; flags="DisableOutput"; description="SSA Visual Edit"; action=function()
Keys("F11 s h e")
end;
}
