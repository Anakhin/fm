Macro {
area="Editor"; key="F4"; flags="DisableOutput"; description="SSA Shift Selection"; action=function()
Keys("F11 s t h s")
end;
}
