Macro {
area="Editor"; key="CtrlAltUp"; flags="DisableOutput"; description="SSA Move phrase up"; action=function()
Keys("F11 s h u")
end;
}
