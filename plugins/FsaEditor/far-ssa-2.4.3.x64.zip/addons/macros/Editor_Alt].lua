Macro {
area="Editor"; key="Alt]"; flags="DisableOutput"; description="SSA Seek End of phrase"; action=function()
Keys("F11 s s e")
end;
}
