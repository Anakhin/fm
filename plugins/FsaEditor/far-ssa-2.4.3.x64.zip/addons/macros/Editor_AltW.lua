Macro {
area="Editor"; key="AltW"; flags="DisableOutput"; description="SSA Style 8"; action=function()
Keys("F11 s y 8")
end;
}
