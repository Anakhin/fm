Macro {
area="Editor"; key="AltG"; flags="DisableOutput"; description="SSA Seek Custom"; action=function()
Keys("F11 s s c")
end;
}
