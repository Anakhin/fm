Macro {
area="Editor"; key="AltS"; flags="DisableOutput"; description="SSA Style 5"; action=function()
Keys("F11 s y 5")
end;
}
