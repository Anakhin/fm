Macro {
area="Editor"; key="Alt/"; flags="DisableOutput"; description="SSA Split Sequential"; action=function()
Keys("F11 s h s")
end;
}
