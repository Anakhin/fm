Macro {
area="Editor"; key="AltO"; flags="DisableOutput"; description="SSA Seek Previous frame"; action=function()
Keys("F11 s s p")
end;
}
