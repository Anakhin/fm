Macro {
area="Editor"; key="Alt="; flags="DisableOutput"; description="SSA Set end of phrase"; action=function()
Keys("F11 s t e")
end;
}
