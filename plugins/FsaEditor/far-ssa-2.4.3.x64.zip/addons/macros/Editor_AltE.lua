Macro {
area="Editor"; key="AltE"; flags="DisableOutput"; description="SSA Style 9"; action=function()
Keys("F11 s y 9")
end;
}
