Macro {
area="Editor"; key="AltP"; flags="DisableOutput"; description="SSA Seek Next frame"; action=function()
Keys("F11 s s n")
end;
}
