Macro {
area="Editor"; key="AltN"; flags="DisableOutput"; description="SSA Split Simultaneous"; action=function()
Keys("F11 s h l")
end;
}
