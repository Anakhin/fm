Plug-in "PortaDev" for Far Manager 3.0
**************************************

Wrapper over the Windows Portable Devices API, which allows to work
with storage devices as a normal file system.

Install:
  Unpack the archive to the Far plugins directory (...Far\Plugins).

Warning:
  This plugin is provided "as is". The author is not responsible for the
  consequences of use of this software.

Artem Senichev (artemsen@gmail.com)
               http://code.google.com/p/farplugs
