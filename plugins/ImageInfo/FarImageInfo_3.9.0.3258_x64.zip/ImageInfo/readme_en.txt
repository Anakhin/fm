Plug-in "Image Info" for Far Manager 3.0
****************************************

Plugin allows you to view image information (EXIF/IPTC/XMP).
To read the meta-data of images plugin uses standard tools of GDI+ and
Exiv2 library (http://www.exiv2.org).

Install:
  Unpack the archive to the Far plugins directory (...Far\Plugins).

Warning:
  This plugin is provided "as is". The author is not responsible for the
  consequences of use of this software.

Artem Senichev (artemsen@gmail.com)
               http://code.google.com/p/farplugs
