Plug-in "JClassInfo" for Far Manager 3.0
****************************************

Java class file viewer and decompilator.
Decompilation is performed by Fernflower (F4) or JAD (F3).

Install:
  Unpack the archive to the Far plugins directory (...Far\Plugins).

Warning:
  This plugin is provided "as is". The author is not responsible for the
  consequences of use of this software.

Artem Senichev (artemsen@gmail.com)
               http://code.google.com/p/farplugs
