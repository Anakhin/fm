To make Oniguruma and PCRE available in LuaFAR Search plugin,
copy 'onig.dll' and 'pcre.dll' to any directory on the Windows PATH.
