      LuaFAR Search v3.x
====================================

*  This is a plugin for Far Manager.
*  It works in Far editor and panels.
*  How to use: see the help file.
*  The plugin is written in Lua programming language.

Installation
-------------
1. Create a directory under %FARHOME%\Plugins, extract files
   and subdirectories into it, then restart Far.

Note
-----
This package works with 2 regex libraries (Far and Lua).
In order to add 2 more libraries (Oniguruma and PCRE),
install "LuaFAR Search add-on" (a separate download).

