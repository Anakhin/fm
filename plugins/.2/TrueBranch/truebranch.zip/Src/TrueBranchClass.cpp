#include <windows.h>
#include "plugin.hpp"
#include "CRT/crt.hpp"
#include "TrueBranchClass.hpp"
#include "TrueMix.hpp"
#include "TrueOpt.hpp"
#include "TrueBranchLng.hpp"

//#include "_syslog.hpp"

#ifdef UNICODE
#define FILE_NAME lpwszFileName
#else
#define FILE_NAME cFileName
#endif

BranchPanel::BranchPanel(int aRootItemsNumber, TRootItem *aRootList)
{
  rootList = aRootList;
  rootItemsNumber = aRootItemsNumber;
  BranchPanelItem = NULL;
  currRoot = NULL;
  alreadyInUpdate = false;
  pressedEsc = BranchItemsNum = BranchItemsMax = 0;
}

static void FreePanelItems(PluginPanelItem *Items, DWORD Total)
{
  if ( Items )
  {
    for ( DWORD I = 0 ; I < Total ; I++ )
    {
      if ( Items[I].Owner )
        free((void*)Items[I].Owner);
#ifdef UNICODE
      if ( Items[I].FindData.lpwszFileName )
        free((void*)Items[I].FindData.lpwszFileName);
#endif
    }
    free(Items);
  }
}

BranchPanel::~BranchPanel()
{
  if ( rootList )
    free(rootList);
  FreePanelItems(BranchPanelItem, BranchItemsMax);
}

int BranchPanel::GetFindData(PluginPanelItem **pPanelItem,int *pItemsNumber,int OpMode)
{
  if ( UpdateItems() )
  {
    *pPanelItem = BranchPanelItem;
    *pItemsNumber = BranchItemsNum;
  }
  else
  {
    *pPanelItem = NULL;
    *pItemsNumber = 0;
  }
  return TRUE;
}

void BranchPanel::GetOpenPluginInfo(struct OpenPluginInfo *oInfo)
{
  oInfo->StructSize = sizeof(*oInfo);
  oInfo->Flags = OPIF_USEFILTER|OPIF_USESORTGROUPS|OPIF_USEHIGHLIGHTING|OPIF_ADDDOTS|OPIF_REALNAMES;
  if ( !Opt.FullPath )
    oInfo->Flags |= OPIF_SHOWNAMESONLY;
  oInfo->HostFile = NULL;
  oInfo->CurDir = _T("");
  oInfo->Format = GetMsg(MTitle);

  static TCHAR Title[256], tmp1[256], tmp2[512];
  lstrcpy(tmp1, GetMsg(MPanelTitle));
  if ( pressedEsc )
    lstrcat(tmp1, GetMsg(MUncomplete));
  int activeNumber = *tmp2 = 0;
  for ( int i = 0 ; i < rootItemsNumber ; i++ )
    if ( rootList[i].State == riActive )
  {
    if ( !activeNumber )
        lstrcpy(tmp2, rootList[i].Name);
    activeNumber++;
  }
  if ( activeNumber > 1 )
    FSF.sprintf(tmp2, GetMsg(MPanelTitleSelected), activeNumber);
  else
  {
    PanelInfo thisPInfo = { 0 };
#ifdef UNICODE
    Info.Control(this, FCTL_GETPANELINFO, 0,(LONG_PTR)&thisPInfo);
#else
    Info.Control(this, FCTL_GETPANELSHORTINFO, &thisPInfo);
#endif
    int len = (thisPInfo.PanelRect.right-thisPInfo.PanelRect.left)-lstrlen(tmp1)-8;
    if ( len < 10 )
      len = 10;
    if ( lstrlen(tmp2) > len )
      FSF.TruncPathStr(tmp2, len);
  }
  lstrcat(lstrcat(lstrcpy(Title, tmp1), tmp2), _T(" "));
  oInfo->PanelTitle = Title;
  static struct KeyBarTitles KeyBar;
  memset(&KeyBar,0,sizeof(KeyBar));
  KeyBar.Titles[7-1]=(TCHAR*)GetMsg(MF7);
  KeyBar.AltShiftTitles[3-1]=(TCHAR*)GetMsg(MAltShiftF3);
  KeyBar.AltShiftTitles[5-1]=(TCHAR*)GetMsg(MAltShiftF5);
  KeyBar.AltShiftTitles[6-1]=(TCHAR*)GetMsg(MAltShiftF6);
  KeyBar.AltShiftTitles[7-1]=(TCHAR*)GetMsg(MAltShiftF7);
  oInfo->KeyBar=&KeyBar;
}

int BranchPanel::SetDirectory(const TCHAR *Dir,int OpMode)
{
  if ( OpMode & OPM_FIND )
    return FALSE;
  if ( !lstrcmp(Dir,_T("..")) )
    return FALSE;
  if ( !lstrcmp(Dir,_T("\\")) )
#ifdef UNICODE
    Info.Control(this,FCTL_CLOSEPLUGIN,0,NULL);
#else
    Info.Control(this,FCTL_CLOSEPLUGIN,(void*)NULL);
#endif
  else
#ifdef UNICODE
    Info.Control(this,FCTL_CLOSEPLUGIN,0,(LONG_PTR)Dir);
#else
    Info.Control(this,FCTL_CLOSEPLUGIN,(void*)Dir);
#endif
  return TRUE;
}

static TCHAR foundDir[512] = _T("");

BOOL CheckForKey(WORD vKey = VK_ESCAPE)
{
  INPUT_RECORD *InputRec;
  DWORD n, ReadCnt;
  BOOL result = FALSE;
  HANDLE Console = GetStdHandle(STD_INPUT_HANDLE);

  if ( GetNumberOfConsoleInputEvents(Console, &n) )
  {
    if ( ( InputRec = (INPUT_RECORD *)malloc(n*sizeof(INPUT_RECORD)) ) != NULL )
    {
      if ( PeekConsoleInput(Console,InputRec,n,&ReadCnt) )
        if ( ReadCnt <= n )
          for ( DWORD i = 0 ; i < n ; i++ )
          {
            if ( InputRec[i].EventType == KEY_EVENT &&
                 InputRec[i].Event.KeyEvent.bKeyDown &&
                 InputRec[i].Event.KeyEvent.wVirtualKeyCode == vKey )
            {
              result=TRUE;
              if ( i > 0 )
                ReadConsoleInput(Console,InputRec,i,&ReadCnt);
              break;
            }
          }
      free(InputRec);
    }
  }
  return result;
}

static bool CheckForEsc(const TCHAR *FullName)
{
  static DWORD dwTicks = 0;
  DWORD dwNewTicks = GetTickCount();
  if (dwNewTicks - dwTicks < 1000)
    return false;
  TCHAR newDir[512];
  TCHAR *p = (TCHAR*)FSF.PointToName(lstrcpy(newDir, FullName));
  if ( p )
  {
    *p = 0;
    if ( FSF.LStricmp(foundDir, newDir) )
    {
      TCHAR truncDir[512];
      FSF.TruncPathStr(lstrcpy(truncDir, lstrcpy(foundDir, newDir)), lstrlen(GetMsg(MFindText)));
      const TCHAR *MsgItems[] = { GetMsg(MTitle), GetMsg(MFindTitle), truncDir, GetMsg(MFindText) };
      Info.Message(Info.ModuleNumber, 0, NULL, MsgItems, ArraySize(MsgItems), 0);
    }
  }
  dwTicks = dwNewTicks;
    if ( CheckForKey() )
    {
      if ( Opt.ESCConfirm )
      {
        const TCHAR *MsgItems[] = { GetMsg(MTitle), GetMsg(MEsc), GetMsg(MAbort), GetMsg(MContinue) };
        if ( wMessage(MsgItems, 2) != 0 )
          return false;
      }
      return true;
    }
  return false;
}

int WINAPI findFunc(const ff_FIND_DATA *ff, const TCHAR *FullName, void *Param)
{
  if ( CheckForEsc(FullName) )
  {
    ((BranchPanel*)Param)->pressedEsc = 1;
    return FALSE;
  }
  if ( ( ff->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) && !Opt.ScanFolders )
    return TRUE;
  if ( ((BranchPanel*)Param)->AddItem(ff, FullName) )
    return TRUE;
  return FALSE;
}

bool BranchPanel::AddDir(const ff_FIND_DATA *ff, const TCHAR *dir)
{
  if ( ff == NULL || ( lstrcmp(ff->FILE_NAME, _T("..")) && lstrcmp(ff->FILE_NAME, _T(".")) ) )
  {
    DWORD Flags = FRS_RECUR;
    if ( Opt.ScanSymlink )
      Flags |= FRS_SCANSYMLINK;
    if ( Opt.FarSearch )
      FSF.FarRecursiveSearch(dir, Opt.FilesMask, findFunc, Flags, this);
    else
      FSF.FarRecursiveSearch(dir, _T("*"), findFunc, Flags, this);
  }
  return true;
}

static bool warnGetInfo(const TCHAR *file)
{
  if ( Opt.WarnGetInfo )
  {
    TCHAR f[512];
    FSF.TruncPathStr(lstrcpy(f, file), 50);
    struct InitDialogItem InitItems[]=
    { //   Type         X1 Y1 X2 Y2 Fo Se Fl                          DB Data
      { DI_DOUBLEBOX,   3, 1,59, 8, 0, 0, DIF_BOXCOLOR,               0, (TCHAR *)MTitle    },
      { DI_TEXT,        5, 2,55, 0, 0, 0, DIF_CENTERTEXT,             0, (TCHAR *)MInfo     },
      { DI_TEXT,        5, 3,55, 0, 0, 0, DIF_CENTERTEXT,             0, f                  },
      { DI_TEXT,        0, 4, 0, 4, 0, 0, DIF_BOXCOLOR|DIF_SEPARATOR, 0, _T("")},
      { DI_CHECKBOX,    5, 5, 0, 0, 1, 0, 0,                          0, (TCHAR *)MDontShow }, //  4
      { DI_TEXT,        0, 6, 0, 6, 0, 0, DIF_BOXCOLOR|DIF_SEPARATOR, 0, _T("")},
      { DI_BUTTON,      0, 7, 0, 0, 0, 0, DIF_CENTERGROUP,            1, (TCHAR *)MOk       }  //  6
    };
    INIT_DIALOG(InitItems);
    EXEC_DIALOG(ExitCode, hDlg, false, InitItems, HlfId.WarnGetInfo, FDLG_WARNING, NULL, 0);
    if ( ExitCode == 6 )
    {
      Opt.WarnGetInfo = GetCheck(4) ? 0 : 1;
      SetOpt(enoWarnGetInfo);
    }
    FREE_DIALOG(hDlg);
  }
  return false;
}

static bool fIncl = false;
static bool fExcl = false;

static inline int matched(const TCHAR *mask, TCHAR *file)
{
#ifdef UNICODE
  return FSF.ProcessName(mask, file, 0, PN_CMPNAMELIST);
#else
  return FSF.ProcessName(mask, file, PN_CMPNAMELIST);
#endif
}

bool BranchPanel::AddItem(const ff_FIND_DATA *ff, const TCHAR *file, bool check)
{
  bool add = true;
  if ( check )
  {
    DWORD dwAttr;
    if ( ff )
      dwAttr = ff->dwFileAttributes;
    else
    {
      dwAttr = GetFileAttributes(file);
      if ( dwAttr == INVALID_FILE_ATTRIBUTES )
        return warnGetInfo(file);
    }
    if ( dwAttr & FILE_ATTRIBUTE_DIRECTORY )
      add = false;
    else if ( !Opt.FarSearch )
    {
      TCHAR *fn = (TCHAR*)file;
      if ( currRoot )
      {
        int len = lstrlen(currRoot);
        if ( !FSF.LStrnicmp(currRoot, file, len) )
          fn += len;
      }
      if ( fIncl && !matched(Opt.IncludeMask, fn) )
        add = false;
      else if ( fExcl && matched(Opt.ExcludeMask, fn))
        add = false;
    }
  }
  if ( add )
  {
    if ( BranchItemsNum >= BranchItemsMax )
    {
      if ( BranchItemsMax > 1 )
        BranchItemsMax *= 2;
      else
        BranchItemsMax = 256;
      struct PluginPanelItem *NewPanelItem = (struct PluginPanelItem *)realloc(BranchPanelItem,sizeof(PluginPanelItem)*BranchItemsMax);
      if ( NewPanelItem == NULL )
      {
        const TCHAR *MsgItems[] = { GetMsg(MTitle), GetMsg(MMemory), GetMsg(MAbort) };
        wMessage(MsgItems, 1);
        return false;
      }
      BranchPanelItem = NewPanelItem;
    }
    struct PluginPanelItem *CurPanelItem = &BranchPanelItem[BranchItemsNum];
    memset(CurPanelItem, 0, sizeof(*CurPanelItem));
    if ( !GetFileInfoAndValidate(file, ff, &CurPanelItem->FindData) )
      return warnGetInfo(file);
    BranchItemsNum++;
  }
  return true;
}

static void WFD2FFD(WIN32_FIND_DATA &wfd, FAR_FIND_DATA &ffd)
{
  ffd.dwFileAttributes=wfd.dwFileAttributes;
  ffd.ftCreationTime=wfd.ftCreationTime;
  ffd.ftLastAccessTime=wfd.ftLastAccessTime;
  ffd.ftLastWriteTime=wfd.ftLastWriteTime;
#ifndef UNICODE
  ffd.nFileSizeHigh=wfd.nFileSizeHigh;
  ffd.nFileSizeLow=wfd.nFileSizeLow;
#else
  ffd.nFileSize = wfd.nFileSizeHigh;
  ffd.nFileSize <<= 32;
  ffd.nFileSize |= wfd.nFileSizeLow;
#endif
#ifndef UNICODE
  ffd.dwReserved0=wfd.dwReserved0;
  ffd.dwReserved1=wfd.dwReserved1;
#else
  ffd.nPackSize = 0;
#endif
#ifndef UNICODE
  lstrcpy(ffd.cFileName,wfd.cFileName);
  *ffd.cAlternateFileName = 0;
#else
  ffd.lpwszFileName = wcsdup(wfd.cFileName);
  ffd.lpwszAlternateFileName = NULL;
#endif
}

bool BranchPanel::GetFileInfoAndValidate(const TCHAR *FileName, const ff_FIND_DATA* SrcData, FAR_FIND_DATA* FindData)
{
  bool ret = FALSE;
  if ( SrcData )
  {
    FindData->dwFileAttributes=SrcData->dwFileAttributes;
    FindData->ftCreationTime=SrcData->ftCreationTime;
    FindData->ftLastAccessTime=SrcData->ftLastAccessTime;
    FindData->ftLastWriteTime=SrcData->ftLastWriteTime;
#ifdef UNICODE
    FindData->nFileSize = SrcData->nFileSize;
    FindData->nPackSize = SrcData->nPackSize;
    FindData->lpwszFileName = wcsdup(FileName);
    FindData->lpwszAlternateFileName = NULL;
#else
    FindData->nFileSizeHigh=SrcData->nFileSizeHigh;
    FindData->nFileSizeLow=SrcData->nFileSizeLow;
    FindData->dwReserved0=SrcData->dwReserved0;
    FindData->dwReserved1=SrcData->dwReserved1;
    lstrcpy(FindData->cFileName,FileName);
    *FindData->cAlternateFileName = 0;
#endif
    ret = TRUE;
  }
  else if ( lstrlen(FileName) )
  {
    DWORD dwAttr = GetFileAttributes(FileName);
    if ( dwAttr != INVALID_FILE_ATTRIBUTES )
    {
      WIN32_FIND_DATA wfd;
      HANDLE fff = FindFirstFile(FileName, &wfd);
      if ( fff != INVALID_HANDLE_VALUE )
      {
        WFD2FFD(wfd,*FindData);
        FindClose(fff);
      }
      else
      {
        wfd.dwFileAttributes = dwAttr;
        HANDLE hFile = CreateFile(FileName,FILE_READ_ATTRIBUTES,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS|FILE_FLAG_POSIX_SEMANTICS,NULL);
        if ( hFile!=INVALID_HANDLE_VALUE )
        {
          GetFileTime(hFile, &wfd.ftCreationTime, &wfd.ftLastAccessTime, &wfd.ftLastWriteTime);
          wfd.nFileSizeLow = GetFileSize(hFile, &wfd.nFileSizeHigh);
          CloseHandle(hFile);
        }
        wfd.dwReserved0 = 0;
        wfd.dwReserved1 = 0;
        WFD2FFD(wfd, *FindData);
      }
#ifdef UNICODE
      if (FindData->lpwszFileName)
        free((void*)FindData->lpwszFileName);
      FindData->lpwszFileName = wcsdup(FileName);
#else
      lstrcpyn(FindData->cFileName,FileName,sizeof(FindData->cFileName)-1);
#endif
      ret = TRUE ;
    }
  }
  if ( ret )
  {
#ifdef UNICODE
    if ( FindData->lpwszFileName == NULL )
    {
      const TCHAR *MsgItems[] = { GetMsg(MTitle), GetMsg(MMemory), GetMsg(MAbort) };
      wMessage(MsgItems, 1);
      ret = FALSE ;
    }
#endif
  }
  return ret;
}

int BranchPanel::UpdateItems(void)
{
  if ( alreadyInUpdate )
    return FALSE;
  alreadyInUpdate = true;
  HANDLE hScreen = Info.SaveScreen(0,0,-1,-1);
  *foundDir = 0;
  if ( BranchPanelItem )
  {
    FreePanelItems(BranchPanelItem, BranchItemsMax);
    BranchPanelItem = NULL;
  }
  BranchItemsNum = BranchItemsMax = 0;
  pressedEsc = 0;
  if ( !Opt.FarSearch )
  {
    fExcl = lstrcmp(Opt.ExcludeMask, _T("")) != 0;
    fIncl = lstrcmp(Opt.IncludeMask, _T("")) && !allFiles(Opt.IncludeMask);
  }
  for ( int i = 0 ; i < rootItemsNumber ; i++ )
    if ( rootList[i].State == riActive )
    {
      currRoot = rootList[i].Name;
      if ( rootList[i].Dir )
        AddDir(NULL, currRoot);
      else
        AddItem(NULL, currRoot);
      currRoot = NULL;
      if ( pressedEsc )
        break;
    }
  if ( BranchItemsNum && Opt.ScanFolders )
  {
    const TCHAR *MsgItems[] = { GetMsg(MTitle), GetMsg(MAddFolders) };
    Info.Message(Info.ModuleNumber, 0, NULL, MsgItems, ArraySize(MsgItems), 0);
    int BranchItemsBak = BranchItemsNum;
    for ( int i = 0 ; i < BranchItemsBak ; i++ )
    {
      TCHAR DirName[512];
      TCHAR *p = (TCHAR*)FSF.PointToName(lstrcpy(DirName, BranchPanelItem[i].FindData.FILE_NAME));
      if ( p > DirName )
      {
        *--p = 0;
        bool add = true;
        for ( int j = BranchItemsBak ; j < BranchItemsNum ; j++ )
          if ( !FSF.LStricmp(DirName, BranchPanelItem[j].FindData.FILE_NAME) )
          {
            add = false;
            break;
          }
        if ( add )
          AddItem(NULL, DirName, false);
      }
    }
  }
  const TCHAR *MsgItems[] = { GetMsg(MTitle), GetMsg(MUpdating) };
  Info.Message(Info.ModuleNumber, 0, NULL, MsgItems, ArraySize(MsgItems), 0);
  struct PluginPanelItem *NewPanelItem = (struct PluginPanelItem *)realloc(BranchPanelItem,sizeof(PluginPanelItem)*(BranchItemsMax = BranchItemsNum));
  if ( BranchItemsNum && NewPanelItem == NULL )
  {
    const TCHAR *MsgItems[] = { GetMsg(MTitle), GetMsg(MMemory), GetMsg(MAbort) };
    wMessage(MsgItems, 1);
  }
  BranchPanelItem = NewPanelItem;
  Info.RestoreScreen(hScreen);
  alreadyInUpdate = false;
  return TRUE;
}

int BranchPanel::PutFiles(struct PluginPanelItem *PanelItem, int ItemsNumber, int, const TCHAR *SrcPath, int)
{
  int ret = 1;
  HANDLE hScreen = BeginPutFiles();
  for ( int i = 0 ; i < ItemsNumber ; i++ )
  {
    if ( !PutOneFile(SrcPath, PanelItem[i]) )
    {
      ret = FALSE;
      break;
    }
  }
  CommitPutFiles(hScreen);
  return ret;
}

HANDLE BranchPanel::BeginPutFiles()
{
  HANDLE hScreen = Info.SaveScreen(0,0,-1,-1);
  const TCHAR *MsgItems[] = { GetMsg(MTitle), GetMsg(MSendFiles) };
  Info.Message(Info.ModuleNumber,0,NULL,MsgItems,ArraySize(MsgItems),0);
  return hScreen;
}

void BranchPanel::CommitPutFiles(HANDLE hRestoreScreen)
{
  Info.RestoreScreen(hRestoreScreen);
}

void add2List(TRootItem **rootList, int n, bool Dir, const TCHAR *Name, const TCHAR* CurDir)
{
  TRootItem *newList = (TRootItem *)realloc(*rootList, sizeof(TRootItem)*(n+1));
  newList[n].Dir = Dir;
  newList[n].State = riActive;
  lstrcpy(newList[n].Name, CurDir);
  if ( newList[n].Name[0] )
    FSF.AddEndSlash(newList[n].Name);
  if ( *Name )
    lstrcat(newList[n].Name, Name);
  else
  {
    TCHAR *p = newList[n].Name+(lstrlen(newList[n].Name)-1);
    if ( *p == _T('\\') )
      *p = 0;
  }
  *rootList = newList;
}

int BranchPanel::packRoot(void)
{
  int j = 0;
  int delCount = 0;
  for ( int i = 0 ; i < rootItemsNumber ; i++ )
  {
    if ( rootList[i].State == riDelete )
      delCount++;
    else
    {
      if ( i != j )
      {
        rootList[j].State = rootList[i].State;
        rootList[j].Dir = rootList[i].Dir;
        lstrcpy(rootList[j].Name, rootList[i].Name);
      }
      j++;
    }
  }
  return delCount;
}

int BranchPanel::PutOneFile(const TCHAR *SrcPath, PluginPanelItem &PanelItem)
{
  TRootItem newItem;
  TCHAR tmp[512], tmp2[512];
  newItem.State = riActive;
  newItem.Dir = ( PanelItem.FindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) ? true : false;
  lstrcpy(newItem.Name, SrcPath);
  if ( *SrcPath )
    FSF.AddEndSlash(newItem.Name);
  lstrcat(newItem.Name, PanelItem.FindData.FILE_NAME);
  bool dupe = false;
  int delCount = 0;
  if ( newItem.Dir )
  {
    for ( int i = 0 ; i < rootItemsNumber ; i++ )
    {
      if ( rootList[i].State == riActive )
    {
        lstrcpy(tmp, newItem.Name);
        FSF.AddEndSlash(tmp);
        if ( rootList[i].Dir )
        {
          lstrcpy(tmp2, rootList[i].Name);
          FSF.AddEndSlash(tmp2);
          if ( !FSF.LStrnicmp(tmp, tmp2, lstrlen(tmp)) )
          {
            lstrcpy(rootList[i].Name, newItem.Name);
            dupe = true;
          }
          else if ( !FSF.LStrnicmp(tmp, tmp2, lstrlen(tmp2)) )
          {
            dupe = true;
            break;
          }
        }
        else
        {
          if ( !FSF.LStrnicmp(tmp, rootList[i].Name, lstrlen(tmp)) )
          {
            delCount++;
            rootList[i].State = riDelete;
          }
        }
    }
    }
    for ( int i = 0 ; i < rootItemsNumber ; i++ )
      if ( rootList[i].State != riDelete )
        for ( int j = i+1 ; j < rootItemsNumber ; j++ )
          if ( rootList[j].State != riDelete && !FSF.LStricmp(rootList[i].Name, rootList[j].Name ) )
          {
            delCount++;
            rootList[j].State = riDelete;
          }
  }
  else
  {
    for ( int i = 0 ; i < rootItemsNumber ; i++ )
    {
      if ( rootList[i].Dir )
      {
        lstrcpy(tmp, rootList[i].Name);
        FSF.AddEndSlash(tmp);
        if ( !FSF.LStrnicmp(tmp, newItem.Name, lstrlen(tmp)) )
          dupe = true;
      }
      else
      {
        if ( !FSF.LStricmp(rootList[i].Name, newItem.Name) )
          dupe = true;
      }
      if ( dupe )
        break;
    }
  }
  if ( delCount )
    rootItemsNumber -= packRoot();
  if ( !dupe )
    add2List(&rootList, rootItemsNumber++, newItem.Dir, newItem.Name, _T(""));
  return TRUE;
}

int BranchPanel::ProcessKey(int Key, unsigned int ControlState)
{
  if ( ! ( Key & PKF_PREPROCESS ) )
  {
    switch ( ControlState )
    {
      case 0:
        switch ( Key )
        {
          case VK_F1:
            Info.ShowHelp(Info.ModuleName, HlfId.Panel, FHELP_USECONTENTS|FHELP_NOSHOWERROR);
            return TRUE;
          case VK_F7:
            ProcessRemoveKey();
            return TRUE;
        }
        break;
      case PKF_SHIFT|PKF_ALT:
        switch ( Key )
        {
          case VK_F3:
            ProcessGoToKey();
            return TRUE;
          case VK_F5:
            ProcessToggleKey(Opt.FullPath);
            return TRUE;
          case VK_F6:
            ProcessToggleKey(Opt.ScanSymlink);
            return TRUE;
          case VK_F7:
            ProcessToggleKey(Opt.ScanFolders);
            return TRUE;
        }
        break;

    }
  }
  return FALSE;
}

void GoToFile(const TCHAR *Target, BOOL AnotherPanel)
{
#ifndef UNICODE
  int FCTL_SetPanelDir  = AnotherPanel?FCTL_SETANOTHERPANELDIR:FCTL_SETPANELDIR;
  int FCTL_GetPanelInfo = AnotherPanel?FCTL_GETANOTHERPANELINFO:FCTL_GETPANELINFO;
  int FCTL_RedrawPanel  = AnotherPanel?FCTL_REDRAWANOTHERPANEL:FCTL_REDRAWPANEL;
  HANDLE _PANEL_HANDLE  = INVALID_HANDLE_VALUE;
#else
  int FCTL_SetPanelDir  = FCTL_SETPANELDIR;
  int FCTL_GetPanelInfo = FCTL_GETPANELINFO;
  int FCTL_RedrawPanel  = FCTL_REDRAWPANEL;
  HANDLE _PANEL_HANDLE  = AnotherPanel?PANEL_PASSIVE:PANEL_ACTIVE;
#endif
  PanelRedrawInfo PRI;
  PanelInfo PInfo;
  const TCHAR *p = FSF.PointToName(const_cast<TCHAR*>(Target));
  TCHAR Name[512], Dir[512] = _T("");
  lstrcpy(Name, p);
  int pathlen = (int)(p-Target);
  if ( pathlen )
    lstrcpyn(Dir, Target, pathlen);
  Dir[pathlen] = _T('\0');
  if ( *Dir )
  {
#ifndef UNICODE
    Info.Control(_PANEL_HANDLE,FCTL_SetPanelDir,Dir);
#else
    Info.Control(_PANEL_HANDLE,FCTL_SetPanelDir,0,(LONG_PTR)Dir);
#endif
  }
#ifndef UNICODE
  Info.Control(_PANEL_HANDLE,FCTL_GetPanelInfo,&PInfo);
#else
  Info.Control(_PANEL_HANDLE,FCTL_GetPanelInfo,0,(LONG_PTR)&PInfo);
#endif
  PRI.CurrentItem = PInfo.CurrentItem;
  PRI.TopPanelItem = PInfo.TopPanelItem;
  for ( int J = 0 ; J < PInfo.ItemsNumber ; J++ )
  {
#ifndef UNICODE
    bool found = !FSF.LStricmp(Name, FSF.PointToName(PInfo.PanelItems[J].FindData.cFileName));
#else
    bool found = false;
    PluginPanelItem* PPI = (PluginPanelItem*)malloc(Info.Control(_PANEL_HANDLE,FCTL_GETPANELITEM,J,0));
    if ( PPI )
    {
      Info.Control(_PANEL_HANDLE,FCTL_GETPANELITEM,J,(LONG_PTR)PPI);
      found = !FSF.LStricmp(Name, FSF.PointToName(PPI->FindData.lpwszFileName));
      free(PPI);
    }
#endif
    if ( found )
    {
      PRI.CurrentItem = J;
      PRI.TopPanelItem = J;
      break;
    }
  }
#ifndef UNICODE
  Info.Control(_PANEL_HANDLE,FCTL_RedrawPanel,&PRI);
#else
  Info.Control(_PANEL_HANDLE,FCTL_RedrawPanel,0,(LONG_PTR)&PRI);
#endif
}

void BranchPanel::ProcessGoToKey()
{
  struct PanelInfo PInfo;
#ifdef UNICODE
  Info.Control(this,FCTL_GETPANELINFO,0,(LONG_PTR)&PInfo);
  TCHAR CurFileName[512] = _T("..");
  DWORD attributes = 0;
  PluginPanelItem* PPI=(PluginPanelItem*)malloc(Info.Control(this,FCTL_GETPANELITEM,PInfo.CurrentItem,0));
  if ( PPI )
  {
    Info.Control(this,FCTL_GETPANELITEM,PInfo.CurrentItem,(LONG_PTR)PPI);
    attributes = PPI->FindData.dwFileAttributes;
    lstrcpy(CurFileName, PPI->FindData.lpwszFileName);
    free(PPI);
  }
#else
  Info.Control(this,FCTL_GETPANELINFO,&PInfo);
  TCHAR *CurFileName = PInfo.PanelItems[PInfo.CurrentItem].FindData.cFileName;
  DWORD attributes = PInfo.PanelItems[PInfo.CurrentItem].FindData.dwFileAttributes;
#endif
  if ( lstrcmp(CurFileName, _T("..")) )
  {
    if ( attributes & FILE_ATTRIBUTE_DIRECTORY )
    {
#ifdef UNICODE
      Info.Control(PANEL_PASSIVE, FCTL_SETPANELDIR,0,(LONG_PTR)CurFileName);
#else
      Info.Control(INVALID_HANDLE_VALUE, FCTL_SETANOTHERPANELDIR,CurFileName);
#endif
    }
    else
      GoToFile(CurFileName, true);
  }
#ifdef UNICODE
  Info.Control(PANEL_PASSIVE, FCTL_REDRAWPANEL, 0, NULL);
#else
  Info.Control(INVALID_HANDLE_VALUE, FCTL_REDRAWANOTHERPANEL,NULL);
#endif
}

void BranchPanel::ProcessToggleKey(int& param)
{
  param = param ? 0 : 1;
#ifdef UNICODE
  Info.Control(this,FCTL_UPDATEPANEL,0,NULL);
  Info.Control(this,FCTL_REDRAWPANEL,0,NULL);
#else
  Info.Control(this,FCTL_UPDATEPANEL,NULL);
  Info.Control(this,FCTL_REDRAWPANEL,NULL);
#endif
}

void BranchPanel::ProcessRemoveKey()
{
  bool pack = false;
  struct FarMenuItemEx *shMenu = (struct FarMenuItemEx *)malloc(sizeof(struct FarMenuItemEx)*(rootItemsNumber+2));
  for ( int i = 0 ; i < rootItemsNumber ; i++ )
  {
    SET_MENUITEM(shMenu, i, rootList[i].Name);
    if ( rootList[i].State == riActive )
      shMenu[i].Flags = MIF_CHECKED;
    else
      shMenu[i].Flags = 0;
  }
  shMenu[rootItemsNumber].Flags = MIF_SEPARATOR;
  SET_MENUITEM(shMenu, rootItemsNumber+1, GetMsg(MConfigAdv));
  const int BreakKeys[] = { VK_INSERT, VK_SPACE, VK_DELETE, VK_RETURN, 0 };
  int BreakCode = -1, Ret = 0;
  for ( ; ; )
  {
    for ( int i = 0 ; i < rootItemsNumber+2 ; i++ )
    {
      if ( i == Ret )
        shMenu[i].Flags |= MIF_SELECTED;
      else
        shMenu[i].Flags &= ~MIF_SELECTED;
    }
    Ret = Info.Menu(Info.ModuleNumber,-1,-1,0,FMENU_WRAPMODE|FMENU_USEEXT,GetMsg(MEdListTitle),GetMsg(MEdListBottom),HlfId.EditList,BreakKeys,&BreakCode,(const FarMenuItem *)shMenu,rootItemsNumber+2);
    if ( Ret >= 0 )
    {
      if ( Ret == rootItemsNumber+1 )
      {
        if ( ( BreakCode < 0 || BreakCode == 3 ) && ConfigAdv() )
        {
#ifndef UNICODE
          Info.Control(this,FCTL_UPDATEPANEL,NULL);
          Info.Control(this,FCTL_REDRAWPANEL,NULL);
#else
          Info.Control(this,FCTL_UPDATEPANEL,0,NULL);
          Info.Control(this,FCTL_REDRAWPANEL,0,NULL);
#endif
        }
        continue;
      }
      switch ( BreakCode )
      {
        case 0:
        case 1:
          switch ( rootList[Ret].State )
          {
            case riActive:
            case riDelete:
              rootList[Ret].State = riIgnore;
              shMenu[Ret].Flags &= ~MIF_CHECKED;
              break;
            case riIgnore:
              rootList[Ret].State = riActive;
              shMenu[Ret].Flags |= MIF_CHECKED;
              break;
          }
          if ( ++Ret >= rootItemsNumber )
            Ret = 0;
          continue;
        case 2:
          switch ( rootList[Ret].State )
          {
            case riActive:
            case riIgnore:
              rootList[Ret].State = riDelete;
              shMenu[Ret].Flags &= ~MIF_CHECKED;
              shMenu[Ret].Flags |= MIF_GRAYED;
              break;
            case riDelete:
              rootList[Ret].State = riIgnore;
              shMenu[Ret].Flags &= ~MIF_CHECKED;
              shMenu[Ret].Flags &= ~MIF_GRAYED;
              break;
          }
          if ( ++Ret >= rootItemsNumber )
            Ret = 0;
          continue;
        default:
          pack = true;
          break;
      }
    }
    break;
  }
  if ( pack )
    rootItemsNumber -= packRoot();
  free(shMenu);
  int activeNumber = 0;
  for ( int i = 0 ; i < rootItemsNumber+2 ; i++ )
    if ( rootList[i].State == riActive )
      activeNumber++;
  if ( !activeNumber )
  {
#ifdef UNICODE
    Info.Control(this,FCTL_CLOSEPLUGIN,0,NULL);
#else
    Info.Control(this,FCTL_CLOSEPLUGIN,(void*)NULL);
#endif
    return;
  }
  if ( pack )
  {
    struct PanelInfo PInfo;
#ifdef UNICODE
    Info.Control(this,FCTL_UPDATEPANEL,0,NULL);
    Info.Control(this,FCTL_REDRAWPANEL,0,NULL);
    Info.Control(PANEL_PASSIVE,FCTL_GETPANELINFO,0,(LONG_PTR)&PInfo);
#else
    Info.Control(this,FCTL_UPDATEPANEL,NULL);
    Info.Control(this,FCTL_REDRAWPANEL,NULL);
    Info.Control(this,FCTL_GETANOTHERPANELSHORTINFO,(void *)&PInfo);
#endif
    if ( PInfo.PanelType == PTYPE_QVIEWPANEL )
    {
#ifndef UNICODE
      Info.Control(this,FCTL_UPDATEANOTHERPANEL,NULL);
      Info.Control(this,FCTL_REDRAWANOTHERPANEL,NULL);
#else
      Info.Control(PANEL_PASSIVE,FCTL_UPDATEPANEL,0,NULL);
      Info.Control(PANEL_PASSIVE,FCTL_REDRAWPANEL,0,NULL);
#endif
    }
  }
}
