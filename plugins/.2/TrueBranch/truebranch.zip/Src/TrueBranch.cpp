#include <windows.h>
#include "plugin.hpp"
#include "farkeys.hpp"
#include "CRT/crt.hpp"
#include "TrueReg.hpp"
#include "TrueMix.hpp"
#include "TrueOpt.hpp"
#include "TrueBranchClass.hpp"
#include "TrueBranchLng.hpp"

//#include "_syslog.hpp"

#if defined(__GNUC__)

#ifdef __cplusplus
extern "C"{
#endif
  BOOL WINAPI DllMainCRTStartup(HANDLE hDll,DWORD dwReason,LPVOID lpReserved);
#ifdef __cplusplus
};
#endif

BOOL WINAPI DllMainCRTStartup(HANDLE hDll,DWORD dwReason,LPVOID lpReserved)
{
  (void) lpReserved;
  (void) dwReason;
  (void) hDll;
  return TRUE;
}
#endif

int WINAPI EXP_NAME(GetMinFarVersion)()
{
  return FARMANAGERVERSION;
}

void WINAPI EXP_NAME(SetStartupInfo)(const struct PluginStartupInfo *psi)
{
  Info = *psi;
  FSF = *psi->FSF;
  Info.FSF = &FSF;
  lstrcpy(PluginRootKey,Info.RootKey);
  lstrcat(PluginRootKey,_T("\\TRUE-BRANCH"));
  GetOpt();
}

static const TCHAR HstFiles[] = _T("TrueBranch_FilesMask");

void WINAPI EXP_NAME(GetPluginInfo)(struct PluginInfo *Info)
{
  static const TCHAR *PluginMenuStrings[1];
  static const TCHAR *PluginCfgStrings[1];
  static const TCHAR *DiskMenuStrings[1];

  Info->StructSize = sizeof(struct PluginInfo);
  Info->Flags = 0;

  if ( Opt.Add2PlugMenu )
  {
    PluginMenuStrings[0] = GetMsg(MTitle);
    Info->PluginMenuStrings = PluginMenuStrings;
    Info->PluginMenuStringsNumber = ArraySize(PluginMenuStrings);
  }
  else
  {
    Info->PluginMenuStringsNumber = 0;
    Info->PluginMenuStrings = 0;
  }

  PluginCfgStrings[0] = GetMsg(MTitle);
  Info->PluginConfigStrings = PluginCfgStrings;
  Info->PluginConfigStringsNumber = ArraySize(PluginCfgStrings);

  if ( Opt.Add2DisksMenu )
  {
   DiskMenuStrings[0] = GetMsg(MTitle);
   Info->DiskMenuStrings = DiskMenuStrings;
   Info->DiskMenuStringsNumber = 1;
   Info->DiskMenuNumbers = &Opt.DisksMenuDigit;
  }
  else
  {
   Info->DiskMenuStringsNumber = 0;
   Info->DiskMenuStrings = 0;
  }
}

int WINAPI EXP_NAME(Configure)( int /*ItemNumber*/ )
{
  const DWORD dh = DIF_HISTORY|DIF_EDITEXPAND;
  struct InitDialogItem InitItems[]=
  { //   Type         X1 Y1 X2 Y2 Fo Se Fl                          DB Data
    { DI_DOUBLEBOX,   3, 1,59,18, 0, 0, DIF_BOXCOLOR,               0, (TCHAR *)MTitle         },
    { DI_CHECKBOX,    5, 2, 0, 0, 1, 0, 0,                          0, (TCHAR *)MAdd2PlugMenu  }, //  1
    { DI_CHECKBOX,    5, 3, 0, 0, 0, 0, 0,                          0, (TCHAR *)MAdd2DisksMenu }, //  2
    { DI_FIXEDIT,     7, 4, 7, 0, 0, 0, DIF_BOXCOLOR|DIF_MASKEDIT,  0, _T("")},                   //  3
    { DI_TEXT,        9, 4, 0, 0, 0, 0, 0,                          0, (TCHAR *)MDisksMenuDigit},
    { DI_TEXT,        0, 5, 0, 0, 0, 0, DIF_BOXCOLOR|DIF_SEPARATOR, 0, _T("")},
    { DI_CHECKBOX,    5, 6, 0, 0, 0, 0, 0,                          0, (TCHAR *)MESCConfirm    }, //  6
    { DI_CHECKBOX,    5, 7, 0, 0, 0, 0, 0,                          0, (TCHAR *)MWarnGetInfo   }, //  7
    { DI_CHECKBOX,    5, 8, 0, 0, 0, 0, 0,                          0, (TCHAR *)MEAutoSelected }, //  8
    { DI_TEXT,        0, 9, 0, 0, 0, 0, DIF_BOXCOLOR|DIF_SEPARATOR, 0, _T("")},
    { DI_CHECKBOX,    5,10, 0, 0, 0, 0, 0,                          0, (TCHAR *)MScanFolders   }, // 10
    { DI_CHECKBOX,    5,11, 0, 0, 0, 0, 0,                          0, (TCHAR *)MScanSymlink   }, // 11
    { DI_CHECKBOX,    5,12, 0, 0, 0, 0, 0,                          0, (TCHAR *)MFullPath      }, // 12
    { DI_TEXT,        0,13, 0, 0, 0, 0, DIF_BOXCOLOR|DIF_SEPARATOR, 0, _T("")},
    { DI_TEXT,        5,14, 0, 0, 0, 0, 0,                          0, (TCHAR *)MFilesMask     },
    { DI_EDIT,        5,15,57, 0, 0, (DWORD_PTR)HstFiles, dh,       0, _T("")},                   // 15
    { DI_TEXT,        0,16, 0, 0, 0, 0, DIF_BOXCOLOR|DIF_SEPARATOR, 0, _T("")},
    { DI_BUTTON,      0,17, 0, 0, 0, 0, DIF_CENTERGROUP,            1, (TCHAR *)MOk            }, // 17
    { DI_BUTTON,      0,17, 0, 0, 0, 0, DIF_CENTERGROUP,            0, (TCHAR *)MCancel        }
  };
  BOOL ret = FALSE;
  INIT_DIALOG(InitItems);
  DialogItems[1].Selected = Opt.Add2PlugMenu;
  DialogItems[2].Selected = Opt.Add2DisksMenu;
  DialogItems[3].Mask = _T("9");
#ifdef UNICODE
  wchar_t numstr[32];
  DialogItems[3].PtrData = numstr;
  FSF.itoa(Opt.DisksMenuDigit,numstr,10);
#else
  FSF.itoa(Opt.DisksMenuDigit,(TCHAR *)DialogItems[3].Data,10);
#endif
  DialogItems[6].Selected = Opt.ESCConfirm;
  DialogItems[7].Selected = Opt.WarnGetInfo;
  DialogItems[8].Selected = Opt.AutoSelected;
  DialogItems[10].Selected = Opt.ScanFolders;
  DialogItems[11].Selected = Opt.ScanSymlink;
  DialogItems[12].Selected = Opt.FullPath;
  SetDataPtr(15,Opt.FilesMask);

  EXEC_DIALOG(ExitCode, hDlg, ret, InitItems, HlfId.Config, 0,NULL, 0);
  if ( ExitCode == 17 )
  {
    Opt.Add2PlugMenu = GetCheck(1);
    Opt.Add2DisksMenu = GetCheck(2);
    Opt.DisksMenuDigit = FSF.atoi(GetDataPtr(3));
    Opt.ESCConfirm = GetCheck(6);
    Opt.WarnGetInfo = GetCheck(7);
    Opt.AutoSelected = GetCheck(8);
    Opt.ScanFolders = GetCheck(10);
    Opt.ScanSymlink = GetCheck(11);
    Opt.FullPath = GetCheck(12);
    lstrcpy(Opt.FilesMask, GetDataPtr(15));
    parseMasks();
    SetOpt(enoAll);
    ret = TRUE;
  }
  FREE_DIALOG(hDlg);
  return ret;
}

#ifdef UNICODE
#define PPIItem(i,s) (PluginPanelItem*)malloc(Info.Control(PANEL_ACTIVE,s ? FCTL_GETSELECTEDPANELITEM : FCTL_GETPANELITEM,i,0))
#define PPIName PPI->FindData.lpwszFileName
#else
#define PPIItem(i,s) ((s ? pi->SelectedItems : pi->PanelItems)+i)
#define PPIName PPI->FindData.cFileName
#endif

static int scanRoot(struct PanelInfo *pi, bool Selected, TRootItem **rootList, const TCHAR* CurDir, int *n)
{
  int subfolders = 0;
  for ( int i = 0 ; i < ( Selected ? pi->SelectedItemsNumber : pi->ItemsNumber ) ; i++ )
  {
    PluginPanelItem* PPI = PPIItem(i, Selected);
    if ( PPI )
    {
#ifdef UNICODE
      Info.Control(PANEL_ACTIVE,( Selected ? FCTL_GETSELECTEDPANELITEM : FCTL_GETPANELITEM ), i, (LONG_PTR)PPI);
#endif
      if ( lstrcmp(PPIName, _T("..")) )
      {
        bool Dir = ( PPI->FindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) ? true : false;
        if ( !Selected || PPI->Flags & PPIF_SELECTED )
        {
          if ( Dir )
            subfolders++;
          if ( rootList )
            add2List(rootList, (*n)++, Dir, PPIName, CurDir);
        }
      }
#ifdef UNICODE
      free(PPI);
#endif
    }
  }
  return subfolders;
}

BOOL ConfigAdv(void)
{
  const DWORD dh = DIF_HISTORY|DIF_EDITEXPAND;
  struct InitDialogItem InitItems[]=
  { //   Type         X1 Y1 X2 Y2 Fo Se Fl                          DB Data
    { DI_DOUBLEBOX,   3, 1,34,10, 0, 0, DIF_BOXCOLOR,               0, (TCHAR *)MTitleAdv    },
    { DI_CHECKBOX,    5, 2, 0, 0, 0, 0, 0,                          0, (TCHAR *)MScanFolders }, // 1
    { DI_CHECKBOX,    5, 3, 0, 0, 0, 0, 0,                          0, (TCHAR *)MScanSymlink }, // 2
    { DI_CHECKBOX,    5, 4, 0, 0, 0, 0, 0,                          0, (TCHAR *)MFullPath    }, // 3
    { DI_TEXT,        0, 5, 0, 0, 0, 0, DIF_BOXCOLOR|DIF_SEPARATOR, 0, _T("")                },
    { DI_TEXT,        5, 6, 0, 0, 0, 0, 0,                          0, (TCHAR *)MFilesMask   },
    { DI_EDIT,        5, 7,32, 0, 0, (DWORD_PTR)HstFiles, dh,       0, _T("")                }, // 6
    { DI_TEXT,        0, 8, 0, 0, 0, 0, DIF_BOXCOLOR|DIF_SEPARATOR, 0, _T("")                },
    { DI_BUTTON,      0, 9, 0, 0, 0, 0, DIF_CENTERGROUP,            1, (TCHAR *)MOk          }, // 8
    { DI_BUTTON,      0, 9, 0, 0, 0, 0, DIF_CENTERGROUP,            0, (TCHAR *)MCancel      }
  };
  BOOL ret = false;
  INIT_DIALOG(InitItems);
  DialogItems[1].Selected = Opt.ScanFolders;
  DialogItems[2].Selected = Opt.ScanSymlink;
  DialogItems[3].Selected = Opt.FullPath;
  SetDataPtr(6,Opt.FilesMask);
  EXEC_DIALOG(ExitCode, hDlg, ret, InitItems, HlfId.ConfigAdv, 0, NULL, 0);
  if ( ExitCode == 8 )
  {
    Opt.ScanFolders = GetCheck(1);
    Opt.ScanSymlink = GetCheck(2);
    Opt.FullPath = GetCheck(3);
    lstrcpy(Opt.FilesMask, GetDataPtr(6));
    parseMasks();
    ret = true;
  }
  FREE_DIALOG(hDlg);
  return ret;
}

HANDLE WINAPI EXP_NAME(OpenPlugin)(int OpenFrom,INT_PTR item)
{
  DWORD difAdd = 0;
  struct PanelInfo pi;
#ifdef UNICODE
  Info.Control(PANEL_ACTIVE, FCTL_GETPANELINFO, 0,(LONG_PTR)&pi);
#else
  Info.Control(INVALID_HANDLE_VALUE, FCTL_GETPANELINFO, &pi);
#endif
  const TCHAR *MsgItems[]={GetMsg(MTitle),GetMsg(MErrBadPanel1),GetMsg(MErrBadPanel2),GetMsg(MCancel)};
  switch ( pi.PanelType )
  {
    case PTYPE_TREEPANEL:
      difAdd = DIF_DISABLE;
      break;
    case PTYPE_FILEPANEL:
      if ( pi.Flags & PFLAGS_REALNAMES )
      {
        if ( !scanRoot(&pi, false, NULL, NULL, NULL) )
        {
          const TCHAR *MsgItems[]={GetMsg(MTitle),GetMsg(MErrSubfolders),GetMsg(MCancel)};
          wMessage(MsgItems, 1);
          return INVALID_HANDLE_VALUE;
        }
        difAdd = scanRoot(&pi, true, NULL, NULL, NULL) ? 0 : MIF_DISABLE;
      }
      else
      {
        wMessage(MsgItems, 1);
        return INVALID_HANDLE_VALUE;
      }
      break;
    default:
      wMessage(MsgItems, 1);
      return INVALID_HANDLE_VALUE;
  }
  if ( difAdd )
    Opt.ScanMode = 0;

  struct FarMenuItemEx shMenu[4];
  memset(&shMenu, 0, sizeof(shMenu));
  SET_MENUITEM(shMenu, 0, GetMsg(MScanCurrent));
  SET_MENUITEM(shMenu, 1, GetMsg(MScanSelected));
  SET_MENUITEM(shMenu, 3, GetMsg(MConfigAdv));
  shMenu[1].Flags = difAdd;
  shMenu[2].Flags = MIF_SEPARATOR;

  BOOL ret = FALSE;
  int ExitCode;
  if ( Opt.AutoSelected )
    ExitCode = difAdd ? 0 : 1;
  else
    ExitCode = Opt.ScanMode;
  for ( ; ; )
  {
    for ( int i = 0 ; i < ArraySize(shMenu) ; i++ )
      if ( i == ExitCode )
        shMenu[i].Flags |= MIF_SELECTED;
      else
        shMenu[i].Flags &= ~MIF_SELECTED;
    ExitCode = Info.Menu(Info.ModuleNumber,-1,-1,0,FMENU_WRAPMODE|FMENU_USEEXT,GetMsg(MScanTitle),NULL,HlfId.Init,NULL,NULL,(const FarMenuItem *)shMenu,ArraySize(shMenu));
    if ( ExitCode == 0 || ExitCode == 1  )
    {
      Opt.ScanMode = ExitCode;
      SetOpt(enoScanMode);
      ret = TRUE;
      break;
    }
    if ( ExitCode == 3 )
    {
      ConfigAdv();
      continue;
    }
    break;
  }
  if ( ret )
  {
    TCHAR CurDir[512] = _T("");
    if ( !pi.Plugin )
    {
#ifdef UNICODE
      FSF.GetCurrentDirectory(512, CurDir);
#else
      lstrcpy(CurDir, pi.CurDir);
#endif
    }
    TRootItem *rootList = NULL;
    int rootSize = 0;
    if ( Opt.ScanMode == 0 )
      if ( pi.Plugin )
        scanRoot(&pi, false, &rootList, CurDir, &rootSize);
      else
        add2List(&rootList, rootSize++, true, _T(""), CurDir);
    else
      scanRoot(&pi, true, &rootList, CurDir, &rootSize);
    if ( rootSize )
    {
      HANDLE hPlugin = new BranchPanel(rootSize, rootList);
      if ( hPlugin == NULL )
        return INVALID_HANDLE_VALUE;
      return hPlugin;
    }
  }
  return INVALID_HANDLE_VALUE;
}

int WINAPI EXP_NAME(GetFindData)(HANDLE hPlugin,struct PluginPanelItem **pPanelItem,int *pItemsNumber,int OpMode)
{
  BranchPanel *Panel=(BranchPanel *)hPlugin;
  return Panel->GetFindData(pPanelItem,pItemsNumber,OpMode);
}

void WINAPI EXP_NAME(GetOpenPluginInfo)(HANDLE hPlugin,struct OpenPluginInfo *Info)
{
  BranchPanel *Panel=(BranchPanel *)hPlugin;
  Panel->GetOpenPluginInfo(Info);
}

int WINAPI EXP_NAME(SetDirectory)(HANDLE hPlugin,const TCHAR *Dir,int OpMode)
{
  BranchPanel *Panel=(BranchPanel *)hPlugin;
  return(Panel->SetDirectory(Dir,OpMode));
}

int WINAPI EXP_NAME(PutFiles)(HANDLE hPlugin,struct PluginPanelItem *PanelItem, int ItemsNumber,int Move,
#ifdef UNICODE
                              const wchar_t* SrcPath,
#endif
                              int OpMode)
{
#ifndef UNICODE
  TCHAR SrcPath[MAX_PATH];
  GetCurrentDirectory(sizeof(SrcPath), SrcPath);
#endif
  BranchPanel *Panel=(BranchPanel *)hPlugin;
  return Panel->PutFiles(PanelItem,ItemsNumber,Move,SrcPath,OpMode);
}

void WINAPI EXP_NAME(ClosePlugin)(HANDLE hPlugin)
{
  delete (BranchPanel *)hPlugin;
}

int WINAPI EXP_NAME(ProcessKey)(HANDLE hPlugin,int Key,unsigned int ControlState)
{
  BranchPanel *Panel=(BranchPanel *)hPlugin;
  return Panel->ProcessKey(Key,ControlState);
}
