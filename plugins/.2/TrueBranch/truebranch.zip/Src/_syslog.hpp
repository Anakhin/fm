#ifndef __SYSLOG_HPP__
#define __SYSLOG_HPP__
static void SysLog(const TCHAR *fmt,...)
{
  const TCHAR *Log = _T("\\TRUE-BRANCH.LOG.TMP");
  TCHAR temp[4096];
  va_list argptr;
  va_start(argptr, fmt);
  wvsprintf(temp, fmt, argptr);
  va_end(argptr);
  HANDLE f = CreateFile(Log, GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
  if ( f != INVALID_HANDLE_VALUE )
  {
    DWORD dwBytesRead = lstrlen(temp)*sizeof(TCHAR), dwBytesWritten = 0;
    DWORD dwPos = SetFilePointer(f, 0, NULL, FILE_END);
#ifdef UNICODE
    if ( !dwPos )
    {
      LockFile(f, 0, 0, 2, 0);
      WriteFile(f, "\xFF\xFE", 2, &dwBytesWritten, NULL);
      UnlockFile(f, 0, 0, 2, 0);
    }
    dwPos = SetFilePointer(f, 0, NULL, FILE_END);
#endif
    LockFile(f, dwPos, 0, dwPos+dwBytesRead, 0);
    WriteFile(f, temp, dwBytesRead, &dwBytesWritten, NULL);
    UnlockFile(f, dwPos, 0, dwPos+dwBytesRead, 0);
  }
  CloseHandle(f);
}
#endif
