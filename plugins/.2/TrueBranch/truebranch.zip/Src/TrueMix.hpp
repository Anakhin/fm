#ifndef __TRUEMIX_HPP__
#define __TRUEMIX_HPP__

#include <windows.h>
#include "plugin.hpp"

struct InitDialogItem
{
  int Type;
  int X1,Y1,X2,Y2;
  int Focus;
  DWORD_PTR Selected;
  DWORD Flags;
  int DefaultButton;
  const TCHAR *Data;
};

extern struct PluginStartupInfo Info;
extern struct FarStandardFunctions FSF;

extern const TCHAR *GetMsg(int MsgId);
extern void InitDialogItems(const struct InitDialogItem *Init,struct FarDialogItem *Item, int ItemsNumber);


#define INIT_DIALOG(Items) struct FarDialogItem DialogItems[ArraySize(Items)]; InitDialogItems(Items, DialogItems, ArraySize(Items))
#ifdef UNICODE
#define EXEC_DIALOG(ExitCode,hDlg,ret,Items,HlfId,Flags,Proc,Param) HANDLE hDlg = Info.DialogInit(Info.ModuleNumber, -1, -1, DialogItems[0].X2+4, DialogItems[0].Y2+2, HlfId, DialogItems, ArraySize(DialogItems), 0, Flags, Proc, (LONG_PTR)Param); \
  if ( hDlg == INVALID_HANDLE_VALUE ) \
    return ret; \
  int ExitCode = Info.DialogRun(hDlg)
#define FREE_DIALOG(hDlg) Info.DialogFree(hDlg)
#else
#define EXEC_DIALOG(ExitCode,hDlg,ret,Items,HlfId,Flags,Proc,Param) int ExitCode = Info.DialogEx(Info.ModuleNumber, -1, -1, DialogItems[0].X2+4, DialogItems[0].Y2+2, HlfId, DialogItems, ArraySize(DialogItems), 0, Flags, Proc, (long)Param)
#define FREE_DIALOG(hDlg)
#endif

#ifdef UNICODE
#define SET_MENUITEM(shMenu,n,v) shMenu[n].Text = v
#define GetCheck(i) (int)Info.SendDlgMessage(hDlg,DM_GETCHECK,i,0)
#define GetDataPtr(i) ((const TCHAR *)Info.SendDlgMessage(hDlg,DM_GETCONSTTEXTPTR,i,0))
#define SetDataPtr(n,v) DialogItems[n].PtrData = v
#else
#define SET_MENUITEM(shMenu,n,v) lstrcpyn(shMenu[n].Text.Text, v, sizeof(shMenu[n].Text.Text))
#define GetCheck(i) DialogItems[i].Selected
#define GetDataPtr(i) DialogItems[i].Data
#define SetDataPtr(n,v) lstrcpy(DialogItems[n].Data, v)
#endif

#define wMessage(MsgItems, Buttons) Info.Message(Info.ModuleNumber, FMSG_WARNING, NULL, (MsgItems), ArraySize(MsgItems), (Buttons))

#endif