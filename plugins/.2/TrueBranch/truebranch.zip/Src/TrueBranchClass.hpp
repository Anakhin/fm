#ifndef __TRUEBRANCHCLASS_HPP__
#define __TRUEBRANCHCLASS_HPP__

#include "plugin.hpp"

enum riState { riActive, riIgnore, riDelete };

struct TRootItem
{
  bool Dir;
  riState State;
  TCHAR Name[512];
};

#ifdef UNICODE
typedef FAR_FIND_DATA ff_FIND_DATA;
#else
typedef WIN32_FIND_DATA ff_FIND_DATA;
#endif

class BranchPanel
{
  private:
    int UpdateItems(void);
    bool GetFileInfoAndValidate(const TCHAR *FilePath, const ff_FIND_DATA* SrcData, FAR_FIND_DATA* FindData);
    void ProcessRemoveKey();
    void ProcessGoToKey();
    void ProcessToggleKey(int&);
    int packRoot(void);

    PluginPanelItem *BranchPanelItem;
    TRootItem *rootList;
    int rootItemsNumber;
    int BranchItemsNum;
    int BranchItemsMax;
    bool alreadyInUpdate;
  public:
    BranchPanel(int aRootItemsNum, TRootItem *aRootList);
    ~BranchPanel();
    bool AddItem(const ff_FIND_DATA *ff, const TCHAR *Name, bool check = true);
    bool AddDir(const ff_FIND_DATA *ff, const TCHAR *Name);
    int GetFindData(PluginPanelItem **pPanelItem,int *pItemsNumber,int OpMode);
    void GetOpenPluginInfo(struct OpenPluginInfo *Info);
    int SetDirectory(const TCHAR *Dir,int OpMode);
    int ProcessKey(int Key,unsigned int ControlState);
    int PutFiles(struct PluginPanelItem *PanelItem,int ItemsNumber,int Move,const TCHAR *SrcPath,int OpMode);
    HANDLE BeginPutFiles();
    void CommitPutFiles(HANDLE hRestoreScreen);
    int PutOneFile(const TCHAR* SrcPath, PluginPanelItem &PanelItem);

    int pressedEsc;
    TCHAR *currRoot;
};

extern void add2List(TRootItem **rootList, int n, bool Dir, const TCHAR *Name, const TCHAR* CurDir);
extern BOOL ConfigAdv(void);

#endif
