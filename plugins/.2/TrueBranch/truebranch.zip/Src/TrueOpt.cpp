#include <windows.h>
#include "plugin.hpp"
#include "farkeys.hpp"
#include "CRT/crt.hpp"
#include "TrueReg.hpp"
#include "TrueOpt.hpp"
#include "TrueMix.hpp"

//#include "_syslog.hpp"

struct HELPIDS HlfId =
{
  _T("Panel"),
  _T("Config"),
  _T("Init"),
  _T("EditList"),
  _T("WarnGetInfo"),
  _T("ConfigAdv")
};

struct RegistryStr REGStr =
{
  _T("Add2PlugMenu"),
  _T("Add2DisksMenu"),
  _T("DisksMenuDigit"),
  _T("ScanMode"),
  _T("ScanFolders"),
  _T("FilesMask"),
  _T("ESCConfirm"),
  _T("AutoSelected"),
  _T("FullPath"),
  _T("WarnGetInfo"),
  _T("ScanSymlink")
};

struct Options Opt =
{
  1,        // Add2PlugMenu
  0,        // Add2DisksMenu
  0,        // DisksMenuDigit
  0,        // ScanMode"),
  0,        // ScanFolders
 _T("*.*"), // FilesMask
  1,        // ESCConfirm
  0,        // AutoSelected
  0,        // FullPath
  1,        // WarnGetInfo
  0         // ScanSymlink
};

static TCHAR *GetCommaWord(TCHAR *Src, TCHAR *Word, const TCHAR *Separators)
{
  int WordPos, SkipBrackets = 0;
  if ( !*Src )
    return NULL;
  for ( WordPos = 0 ; *Src ; Src++,WordPos++ )
  {
    switch ( SkipBrackets )
    {
      case 0:
        if ( *Src == _T('[') && lstrchr(Src+1, _T(']')) != NULL )
          SkipBrackets = 2;
        if ( *Src == _T('\"') && lstrchr(Src+1, _T('\"')) != NULL )
          SkipBrackets = 1;
        break;
      case 1:
        if ( *Src == _T('\"') )
          SkipBrackets = 0;
        break;
      case 2:
        if ( *Src == _T(']') )
          SkipBrackets = 0;
        break;
    }
    if ( SkipBrackets == 0 && lstrchr(Separators, *Src) )
    {
      Word[WordPos] = 0;
      Src++;
      while ( _istspace(*Src) )
        Src++;
      return Src;
    }
    else
      Word[WordPos] = *Src;
  }
  Word[WordPos] = 0;
  return Src;
}

bool allFiles(const TCHAR* Mask)
{
  return !lstrcmp(Mask, _T("*.*")) || !lstrcmp(Mask, _T("*"));
}

static bool compactMask(TCHAR *str, bool FullPath)
{
  if ( *str )
  {
    TCHAR *p;
    while ( ( p = lstrstr(str, _T("**")) ) != NULL )
      lstrcpy(p, p+1);
    if ( FullPath )
    {
      TCHAR w[512];
#ifdef UNICODE
      TCHAR *bak = wcsdup(str);
#else
      TCHAR *bak = strdup(str);
#endif
      TCHAR *s = bak;
      *str = 0;
      while ( ( s = GetCommaWord(s, w, _T(",;")) ) != NULL )
      {
        FSF.Trim(w);
        bool quote = *w == _T('\"');
        FSF.Unquote(w);
        if ( *w )
        {
          if ( allFiles(w) )
          {
            lstrcpy(str, _T("*"));
            return true;
          }
          if ( *str )
            lstrcat(str, _T(","));
          if ( quote )
            lstrcat(str, _T("\""));
          if ( !lstrstr(w, _T("\\")) )
            lstrcat(str, _T("*\\"));
          lstrcat(str, w);
          if ( quote )
            lstrcat(str, _T("\""));
        }
      }
      free(bak);
    }
  }
  return false;
}

bool parseMasks(void)
{
  bool FullPath = lstrchr(Opt.FilesMask, _T('\\')) != NULL;
  if ( lstrchr(Opt.FilesMask, _T('/')) )
    Opt.FarSearch = true;
  else if ( !FullPath )
    Opt.FarSearch = true;
  else
  {
    Opt.FarSearch = false;
    TCHAR *p = lstrchr(lstrcpy(Opt.IncludeMask, Opt.FilesMask), _T('|'));
    if ( p )
    {
      lstrcpy(Opt.ExcludeMask, p+1);
      *p = 0;
    }
    else
      *Opt.ExcludeMask = 0;
    compactMask(Opt.IncludeMask, FullPath);
    return compactMask(Opt.ExcludeMask, FullPath);
  }
  return false;
}

void GetOpt(void)
{
  Opt.Add2PlugMenu   = GetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.Add2PlugMenu,   Opt.Add2PlugMenu  );
  Opt.Add2DisksMenu  = GetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.Add2DisksMenu,  Opt.Add2DisksMenu );
  Opt.DisksMenuDigit = GetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.DisksMenuDigit, Opt.DisksMenuDigit);
  Opt.ScanMode       = GetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.ScanMode,       Opt.ScanMode);
  Opt.ScanFolders    = GetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.ScanFolders,    Opt.ScanFolders);
  Opt.ESCConfirm     = GetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.ESCConfirm,     Opt.ESCConfirm);
  Opt.AutoSelected   = GetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.AutoSelected,   Opt.AutoSelected);
  Opt.FullPath       = GetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.FullPath,       Opt.FullPath);
  Opt.WarnGetInfo    = GetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.WarnGetInfo,    Opt.WarnGetInfo);
  Opt.ScanSymlink    = GetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.ScanSymlink,    Opt.ScanSymlink);
  GetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.FilesMask, Opt.FilesMask, Opt.FilesMask, sizeof(Opt.FilesMask));
  parseMasks();
}

void SetOpt(enOpt what)
{
  if ( what & enoScanMode )
    SetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.ScanMode,       Opt.ScanMode);
  if ( what & enoWarnGetInfo )
    SetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.WarnGetInfo,    Opt.WarnGetInfo);
  if ( what & enoOther )
  {
    SetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.Add2PlugMenu,   Opt.Add2PlugMenu);
    SetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.Add2DisksMenu,  Opt.Add2DisksMenu);
    SetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.DisksMenuDigit, Opt.DisksMenuDigit);
    SetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.ScanFolders,    Opt.ScanFolders);
    SetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.FilesMask,      Opt.FilesMask);
    SetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.ESCConfirm,     Opt.ESCConfirm);
    SetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.AutoSelected,   Opt.AutoSelected);
    SetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.ScanSymlink,    Opt.ScanSymlink);
    SetRegKey(HKEY_CURRENT_USER, _T(""), REGStr.FullPath,       Opt.FullPath);
  }
}
