#ifndef __TRUEOPT_HPP__
#define __TRUEOPT_HPP__

#ifdef UNICODE
#define lstrchr(s,c) wcschr(s,c)
#define lstrstr(s,c) wcsstr(s,c)
#else
#define lstrchr(s,c) strchr(s,c)
#define lstrstr(s,c) strstr(s,c)
#endif

struct RegistryStr
{
  const TCHAR *Add2PlugMenu;
  const TCHAR *Add2DisksMenu;
  const TCHAR *DisksMenuDigit;
  const TCHAR *ScanMode;
  const TCHAR *ScanFolders;
  const TCHAR *FilesMask;
  const TCHAR *ESCConfirm;
  const TCHAR *AutoSelected;
  const TCHAR *FullPath;
  const TCHAR *WarnGetInfo;
  const TCHAR *ScanSymlink;
};

struct Options
{
  int Add2PlugMenu;
  int Add2DisksMenu;
  int DisksMenuDigit;
  int ScanMode;
  int ScanFolders;
  TCHAR FilesMask[1024];
  int ESCConfirm;
  int AutoSelected;
  int FullPath;
  int WarnGetInfo;
  int ScanSymlink;

  TCHAR IncludeMask[4*1024];
  TCHAR ExcludeMask[4*1024];
  bool FarSearch;
};

struct HELPIDS
{
  const TCHAR *Panel;
  const TCHAR *Config;
  const TCHAR *Init;
  const TCHAR *EditList;
  const TCHAR *WarnGetInfo;
  const TCHAR *ConfigAdv;
};

enum enOpt
{
  enoScanMode    = 0x0001,
  enoWarnGetInfo = 0x0002,
  enoOther       = 0x0004,
  enoAll         = 0x00FF
};

extern struct RegistryStr REGStr;
extern struct Options Opt;
extern struct HELPIDS HlfId;
extern void GetOpt(void);
extern void SetOpt(enOpt);

extern bool allFiles(const TCHAR*);
extern bool parseMasks(void);
extern void parseKey(void);

#endif