FilterLines 1.6 plugin for Far Manager 2.0.
(C) Igor Yudincev, 2009.

  This editor plugin looks for the given sequence of characters in edited text
and removes strings that do not contain it. The result is shown immediately
after input of each character.
  Use Ctrl+Shift+(Up/Dn/PgUp/PgDn/Home/End) to navigate through search results.
