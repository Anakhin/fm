#include <crt.hpp>
#include <windows.h>

static size_t nData;
static void **Data;

void StackPush(void *item) {
	void **NewData = (void **)malloc((nData+1)*sizeof(void*));
	if (Data!=NULL) {
		memcpy(NewData,Data,nData*sizeof(void*));
		free(Data);
	}
	NewData[nData] = item;
	nData++;
	Data = NewData;
}

void *StackPop() {
	if (nData==0)
		return NULL;
	void *result = Data[nData-1];
	void **NewData = NULL;
	if (nData>1) {
		NewData = (void **)malloc((nData-1)*sizeof(void*));
		memcpy(NewData,Data,(nData-1)*sizeof(void*));
	}
	free(Data);
	Data = NewData;
	nData--;
	return result;
}

void *StackPeek(int iNestLevel=0) {
	if (nData-iNestLevel<=0)
		return NULL;
	return Data[nData-iNestLevel-1];
}
