#pragma once

void StackPush(void *p);
void *StackPop();
void StackClean();
void *StackPeek(int iNestLevel=0);
