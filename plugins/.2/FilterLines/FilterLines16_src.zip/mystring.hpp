int Length(wchar_t *str);
bool SetLength(wchar_t **pStr, int len);
