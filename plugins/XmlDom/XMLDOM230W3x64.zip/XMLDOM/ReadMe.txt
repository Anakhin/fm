
                   XML Browser Plugin for FAR

                   Version 2.30, 26 Dec 2012.


--------------------------------------------------------------------------
DISTRIBUTION: Freeware. You may freely distribute this plugin without any
modifications if you make no commercial profit of distribution, keep
all accompanying fiels together with the plugin and leave them unchanged.
--------------------------------------------------------------------------

This plugin displays contents of any XML file or Internet resource
as an archive or directory on FAR panel.
You may do all standard FAR operations with XML elements.
Minimal editing is implemented. XPath selection and evaluation is supported.
Flexible redefinition of text displayed in columns is also possible using XPath.

For more information, see the help file.

The plugin uses Microsoft XML DOM services provided by msxml3.dll.
To use this plugin on Windows 2000, get msxml3.dll and msxml3r.dll from
an XP installation.

Installation: create a subdir under your Plugins\ directory (e.g.
Plugins\XMLDOM), extract all the files there, restart FAR and enjoy :)


Michael Yutsis
Ramat Gan, Israel
yutsis@gmail.com
http://michael-y.org/FAR
