Plug-in "Hunspell" for Far Manager 3.0
**************************************

Spell checking in built-in Far editor.

Based on a hunspell library (http://hunspell.sourceforge.net/).
The package includes the following dictionaries:
- English;
- Russian.

To start spell checking select plug-in form plug-ins menu (F11) in editor.
Spellcheck starts from the current line.

Install:
  Unpack the archive to the Far plugins directory (...Far\Plugins).

Warning:
  This plugin is provided "as is". The author is not responsible for the
  consequences of use of this software.

Artem Senichev (artemsen@gmail.com)
               http://code.google.com/p/farplugs
