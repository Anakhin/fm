function export.GetGlobalInfo()
  return {
    Version       = { 1, 0, 0, 0 },
    MinFarVersion = { 3, 0, 0, 2827 },
    Guid          = win.Uuid("0c151710-6f13-4020-8536-745e712b6944"),
    Title         = "Block Shift",
    Description   = "A LuaFAR clone of the Block Indent plugin",
    Author        = "Shmuel Zeigerman",
  }
end
