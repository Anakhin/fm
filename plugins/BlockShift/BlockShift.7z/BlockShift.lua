-- Translated to Lua/LuaFAR by Shmuel Zeigerman, 2011-02-26.

--[[
    Block Indent plugin for FAR Manager
    Copyright (C) 2001 Alex Yaroslavsky

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
--]]
----------------------------------------------------------------------------

-- far.ReloadDefaultScript = true
local F = far.Flags
local M = far.GetMsg

local MTitle, MShiftTabLeft, MShiftTabRight, MShiftSpaceLeft, MShiftSpaceRight = 0,1,2,3,4
local MenuGuid = win.Uuid("b687ece2-3d05-4298-b416-eb82342a518a")

function export.GetPluginInfo()
  return {
    Flags = bit64.bor(F.PF_EDITOR, F.PF_DISABLEPANELS),
    PluginMenuGuids   = MenuGuid.."",
    PluginMenuStrings = { M(MTitle) },
  }
end

function export.Open (OpenFrom, Guid, Item)
  local MenuItems = {
    { text=M(MShiftTabLeft) },   { text=M(MShiftTabRight) },
    { text=M(MShiftSpaceLeft) }, { text=M(MShiftSpaceRight) },
  }
  local MenuProps = { SelectIndex=1, Title=M(MTitle), Flags=F.FMENU_WRAPMODE }

  local item, pos = far.Menu(MenuProps, MenuItems)
  if not item then return end

  local ei = editor.GetInfo()

  local IndentStr = pos < 3 and '\t' or ' '
  local IndentSize = pos < 3 and ei.TabSize or 1
  local IndentRight = (pos % 2 == 0)

  local line = ei.CurLine
  local loop
  if ei.BlockType ~= F.BTYPE_NONE then
    local egs = editor.GetString(nil, -1)
    if egs.SelStart ~= -1 then
      loop = true
      line = ei.BlockStartLine
    end
  end

  editor.UndoRedo(nil, F.EUR_BEGIN)
  for CurLine = line, ei.TotalLines-1 do
    editor.SetPosition(nil, CurLine, 0, nil, nil, nil, 0)
    local egs = editor.GetString(nil, -1)
    if loop and (egs.SelStart == -1 or egs.SelStart == egs.SelEnd) then
      break
    end
    local j = egs.StringText:find("[^ \t]")
    if j and (j > 1 or IndentRight) then
      local DestPos = editor.RealToTab(nil, -1, j) - 1
      local x = math.floor(DestPos / IndentSize)
      if IndentRight then x = x + 1
      elseif DestPos % IndentSize == 0 then x = x - 1
      end
      editor.SetString(nil, -1, egs.StringText:sub(j), egs.StringEOL)
      for i = 1, x do editor.InsertText(nil, IndentStr) end
    end
    if not loop then break end
  end

  editor.SetPosition(nil, ei.CurLine, ei.CurPos, nil, ei.TopScreenLine,
                        ei.LeftPos, ei.Overtype)
  editor.UndoRedo(nil, F.EUR_END)
end
