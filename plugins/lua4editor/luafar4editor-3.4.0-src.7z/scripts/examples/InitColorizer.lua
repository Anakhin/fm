Macro {
  area="Shell"; key="AltShiftF24"; flags="RunAfterFARStart"; description="Init colorizer"; action = function()
     CallPlugin("6f332978-08b8-4919-847a-efbb6154c99a","InitColorizer")
  end;
}
