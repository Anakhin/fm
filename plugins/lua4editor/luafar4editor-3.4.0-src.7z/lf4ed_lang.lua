require ("far2.makelang") (

---- 1-st argument
"lf4ed_message.lua",

---- 2-nd argument
{
  { filename = "lf4ed_eng.lng",
    line1 = ".Language=English,English",
  },
  { filename = "lf4ed_rus.lng",
    line1 = ".Language=Russian,Russian (Русский)",
  },
  -- { filename = "lf4ed_cze.lng",
  --   line1 = ".Language=Czech,Czech (Čeština)",
  -- },
},

---- template file names
...)

