      LuaFAR for Editor v3.x.x
  Set of utilities for FAR Editor
====================================

1. Installation:
   Create a directory under %FARHOME%\Plugins, extract files and subdirectories
   into it, then restart Far.

2. The following utilities are included:
   -- Sort Lines
   -- Reformat Block
   -- Multi-Line Replace
   -- Block Sum
   -- Lua Expression
   -- Lua Script
   More utilities can be added by the user.

3. How to use - see the help file and the manual.

4. Both the plugin and the utilities are written in Lua programming language.
