This directory is intended for installing packets of scripts.
