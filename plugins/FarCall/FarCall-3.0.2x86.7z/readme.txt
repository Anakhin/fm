
hi

this plugin allows to call external batch files & import environment variables to Far process

how to use:

1. type call:batch_file_name
or
2. set cursor on batch file, press F11 & select "Far Call" plugin