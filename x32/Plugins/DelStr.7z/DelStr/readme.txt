﻿	Delete strings FAR2 plugin

Внимание любителям давать советы! Я знаю о "Search & Replace" и "ReSearch".
Плагин этот я писал для себя, чтобы была возможность сделать эти простые
операции по-быстрому. Ну может еще кому пригодится.

© 2011 Andrew Grechkin
	mailto: andrew.grechkin@gmail.com
	jabber: andrew.grechkin@gmail.com

© 2011 datamanRB
	mailto:
	jabber:

Исходный код:
	http://code.google.com/p/andrew-grechkin
